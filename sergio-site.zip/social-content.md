# 🎵 חבילת קידום — SERGIO · "Poli Poli Sheli"

קהל יעד: 20-35, אפרו-טכנו / אלקטרוני · קישור לדף: coruscating-cobbler-f77488.netlify.app
(אחרי ששמת שם יפה ב-Netlify — תחליף את הקישור בכל מקום בקובץ.)

---

## 📌 טקסטים לביו (העתק-הדבק)

**Instagram:**
```
SERGIO 🌀 Afro-Techno producer
🎧 New single "Poli Poli Sheli" — out now
👇 האזן עכשיו
[הקישור לדף]
```

**TikTok:**
```
afro-techno 🔊 | new single OUT
"Poli Poli Sheli" 🌀 link below
```

**YouTube (About):**
```
SERGIO — אמן ומפיק מוזיקה אלקטרונית (Afro-Techno / Afro House).
סינגל חדש: "Poli Poli Sheli". להאזנה ולכל הקישורים: [הקישור לדף]
ערוץ רשמי: youtube.com/@SergioOfficialMusic25
```

---

## 🗓️ לוח תוכן — 4 שבועות (12 פוסטים)

> שעות שיא לקהל 20-35: ימים א'-ה' 19:00-22:00, סופ"ש 12:00-14:00 ו-20:00-23:00.

### שבוע 1 — השקה

**פוסט 1 · יום א' 20:00 · אינסטגרם פוסט/Reel**
ויזואל: רגע הדרופ הכי חזק (15-20ש') + טקסט על המסך "wait for it 🌀"
```
POLI POLI SHELI is OUT 🔊
הסינגל החדש שלי — afro-techno, original mix.
תעלו את הווליום ותתמכרו לגרוב 🌀
🎧 link in bio
```
האשטגים: `#afrohouse #afrotechno #afrotech #melodichouse #organichouse #electronicmusic #newmusic #djlife #טכנו #מוזיקהאלקטרונית`

**פוסט 2 · יום ג' 21:00 · TikTok / Reel**
ויזואל: POV ידיים על הקונטרולר/מיקסר בזמן הדרופ
```
when the beat hits at 1:15 🥁🔥
"Poli Poli Sheli" out now 🌀
מי בא לרקוד? 💃
```
האשטגים: `#afrohouse #afrotech #djset #producerlife #fyp #foryou #housemusic #electronicmusic`

**פוסט 3 · יום ה' 20:30 · סטורי + פוסט**
ויזואל: תמונת העטיפה + ספירת האזנות ("עברנו X האזנות 🙏")
```
תודה על כל ההאזנות 🖤 זה רק ההתחלה.
שתפו עם מי שאוהב אפרו-טכנו 🔁
🎧 link in bio
```
האשטגים: `#afrohouse #afrotechno #supportlocalartists #newmusic #טכנו`

### שבוע 2 — מאחורי הקלעים

**פוסט 4 · יום א' 20:00 · Reel**
ויזואל: סטודיו / תהליך יצירה / סאונד-דיזיין קצר
```
ככה נולד "Poli Poli Sheli" 🎛️
שעות על הגרוב הזה. שווה כל שנייה.
🎧 הסינגל המלא — link in bio
```
האשטגים: `#producerlife #studiolife #afrohouse #musicproduction #behindthemusic #electronicmusic`

**פוסט 5 · יום ג' 21:00 · TikTok**
ויזואל: "name a track that does THIS to you 🌀" + קטע הגרוב
```
afro-techno שמרים את הנשמה 🔊
"Poli Poli Sheli" — out now
```
האשטגים: `#afrohouse #afrotech #melodictechno #fyp #housemusic #undergroundmusic`

**פוסט 6 · יום ה' 20:30 · פוסט**
ויזואל: תמונה אווירתית (שקיעה/קלאב/מדבר)
```
המוזיקה הזו נוצרה בשביל הרגעים האלה 🌅🔊
"Poli Poli Sheli" 🌀 SERGIO
🎧 link in bio
```
האשטגים: `#afrohouse #organichouse #sunsetvibes #electronicmusic #newmusic`

### שבוע 3 — אינטראקציה

**פוסט 7 · יום א' 20:00 · Reel + שאלה**
ויזואל: קטע מהשיר + "save this for your next set 🎧"
```
DJs — הטראק הזה לסט הבא שלכם 🔊
"Poli Poli Sheli" · free your floor 🌀
```
האשטגים: `#djtools #afrohouse #djset #afrotech #housemusic #fyp`

**פוסט 8 · יום ג' 21:00 · TikTok**
ויזואל: ריאקשן/דואט פוטנציאלי — "duet this with your dance 💃"
```
show me your move to this 🌀🔥
"Poli Poli Sheli" — SERGIO
```
האשטגים: `#dancechallenge #afrohouse #fyp #afrotech #viralsound`

**פוסט 9 · יום ה' 20:30 · סטורי אינטראקטיבי**
ויזואל: סקר בסטורי — "איזה חלק בשיר הכי אהבת? 🥁/🎹/🌀"
```
ספרו לי — איזה רגע בשיר תפס אתכם? 👇
🎧 link in bio
```
האשטגים: `#afrohouse #engagement #newmusic`

### שבוע 4 — מומנטום והבא בתור

**פוסט 10 · יום א' 20:00 · Reel**
ויזואל: "1 month of Poli Poli Sheli 🌀" + הדגשות/קטעים
```
חודש ל-"Poli Poli Sheli" 🖤 תודה לכל מי שהאזין ושיתף.
אם עוד לא שמעתם — עכשיו זה הזמן 🔊
🎧 link in bio
```
האשטגים: `#afrohouse #afrotechno #newmusic #thankyou #electronicmusic`

**פוסט 11 · יום ג' 21:00 · TikTok**
ויזואל: טיזר/רמז לטראק הבא ("next one is coming 👀")
```
this is just the start 🌀 הבא בתור בדרך...
בינתיים: "Poli Poli Sheli" on repeat 🔁
```
האשטגים: `#afrohouse #afrotech #comingsoon #producerlife #fyp`

**פוסט 12 · יום ה' 20:30 · פוסט סיכום**
ויזואל: קולאז' של הרגעים/תגובות מהחודש
```
מה חשבתם על "Poli Poli Sheli"? 🌀
עקבו לעוד אפרו-טכנו בקרוב 🔊🖤
🎧 link in bio
```
האשטגים: `#afrohouse #afrotechno #followformore #electronicmusic #טכנו`

---

## 🎬 6 תסריטי Reels/Shorts (שנייה-שנייה)

**1. "The Drop"**
- 0-3ש': מסך כהה + טקסט "wait for the drop 🌀"
- 3-15ש': הקטע הכי חזק בשיר + ויזואלייזר/קליפ מסיבה
- סוף: לוגו SERGIO + "out now 🎧"

**2. "POV — מאחורי הדקים"**
- ידיים על הקונטרולר בתקריב, מסונכרן לביט
- טקסט: "afro-techno hits different 🔊"

**3. "Studio session"**
- קטעי תהליך (לופים, פדים, מיקס) במהירות
- טקסט: "how Poli Poli Sheli was made 🎛️"

**4. "Sunset / nature sync"**
- b-roll של שקיעה/מדבר/ים מסונכרן לגרוב
- טקסט: "music for golden hour 🌅"

**5. "Dance challenge"**
- אתה/חבר רוקד לקטע, קריאה ל-duet
- טקסט: "show me your move 💃🌀"

**6. "Countdown / teaser לבא"**
- 5ש' טיזר של טראק עתידי + "next one 👀"
- מפנה ל-"Poli Poli Sheli" בינתיים

---

## ✅ מדריך הקמה — Metricool (תזמון אוטומטי, חינם)

1. היכנס ל-**metricool.com** → הירשם חינם (Google/מייל, על שמך).
2. בלוח הבקרה → **Connections / Brands** → חבר את החשבונות:
   - Instagram (דרך Facebook/Meta — חיבור רשמי, בלי סיסמה אלינו)
   - TikTok · YouTube · Facebook (אם יש)
3. **Planner** → צור פוסט → הדבק טקסט+האשטגים מהקובץ הזה → צרף ויזואל → בחר תאריך/שעה → Schedule.
4. חזור על זה ל-12 הפוסטים לפי הלוח למעלה.

**בדיקה:** תזמן פוסט-בדיקה אחד לעוד 10 דקות, ותראה שהוא יוצא לבד בחשבון האמיתי. עובד? → טען את כל החודש.

🔒 חשוב: החיבור הוא דרך כפתורי ההתחברות הרשמיים של הפלטפורמות (OAuth). **אתה לא מוסר סיסמה לאף אחד — כולל לא ל-Metricool ולא אליי.**
